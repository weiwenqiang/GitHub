SMSSDK for Android
==================

This is a demonstration project for <a href="http://www.mob.com/downloadDetail/SMS/android">SMSSDK</a>.

This project uses the main functions of SMSSDK.<br>
With SMSSDK ,your app can securely and quickly register new users
by using a SMS verification code sent to their Mobile phone.


Getting up
----------
We offer two popular IDE guide to integrate SMSSDK.

###Android Studio

just clone down and open with Studio.

###Eclipse

just clone down and import Project directory to Eclipse.


Need more support about SMSSDK? please check at [Mob.com](http://wiki.mob.com/android-%E7%9F%AD%E4%BF%A1sdk%E9%9B%86%E6%88%90%E6%96%87%E6%A1%A3/) (Chinese)
