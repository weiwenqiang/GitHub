package com.study.android.kehan.eventbustest.Bean;

/**
 * Created by kehan on 16-7-25.
 */
public class EventBusMessage {

    private String message;

    public EventBusMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
